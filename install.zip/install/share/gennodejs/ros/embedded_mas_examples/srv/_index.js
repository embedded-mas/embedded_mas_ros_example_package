
"use strict";

let SumArray = require('./SumArray.js')

module.exports = {
  SumArray: SumArray,
};
